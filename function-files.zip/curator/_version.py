"""Curator Version"""
__version__ = '5.8.4'
